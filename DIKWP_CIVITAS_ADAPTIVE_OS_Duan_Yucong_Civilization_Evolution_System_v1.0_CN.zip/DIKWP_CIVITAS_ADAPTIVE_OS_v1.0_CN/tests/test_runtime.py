#!/usr/bin/env python3
import importlib.util
import json
import math
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RUNTIME_PATH = ROOT / 'runtime' / 'civitas_runtime.py'
spec = importlib.util.spec_from_file_location('civitas_runtime', RUNTIME_PATH)
rt = importlib.util.module_from_spec(spec)
sys.modules['civitas_runtime'] = rt
assert spec.loader is not None
spec.loader.exec_module(rt)


class CivitasRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.inputs = rt.load_inputs(rt.DEFAULT_CONFIG, rt.DEFAULT_SCENARIOS, rt.DEFAULT_PROFILE, rt.DEFAULT_SIGNALS)
        cls.packet = rt.build_packet(cls.inputs)

    def test_probabilities_sum_to_one(self):
        total = sum(x['probability'] for x in self.packet['scenario_forecast'])
        self.assertAlmostEqual(total, 1.0, places=6)

    def test_top_scenario_is_fragmented_acceleration(self):
        self.assertEqual(self.packet['scenario_forecast'][0]['scenario_id'], 'fragmented_acceleration')

    def test_vital_energy_generates_immediate_action(self):
        titles = [a['title'] for a in self.packet['actions']['U7']]
        self.assertIn('建立七日能量止损协议', titles)

    def test_purpose_integrity_is_strength(self):
        self.assertIn('目的完整性与伦理边界', self.packet['individual_assessment']['strengths'])

    def test_packet_is_deterministic(self):
        packet2 = rt.build_packet(self.inputs)
        self.assertEqual(self.packet['reproducibility_hash'], packet2['reproducibility_hash'])
        self.assertEqual(self.packet['packet_id'], packet2['packet_id'])

    def test_optionality_is_bounded(self):
        opt = self.packet['optionality']
        self.assertGreaterEqual(opt['current'], 0)
        self.assertLessEqual(opt['projected'], 100)
        self.assertGreater(opt['projected'], opt['current'])

    def test_no_human_worth_claim(self):
        note = self.packet['individual_assessment']['assessment_note']
        self.assertIn('不表示人的价值', note)

    def test_actualization_calibration(self):
        actual = rt.load_json(rt.DEFAULT_ACTUALIZATION)
        cal = rt.calibrate_forecast(self.packet, actual)
        self.assertEqual(cal['observed_rank_in_forecast'], 1)
        self.assertGreaterEqual(cal['multiclass_brier_score'], 0)
        self.assertTrue(math.isfinite(cal['civilization_state_rmse']))

    def test_forecast_influence_notice_present(self):
        self.assertIn('改变使用者行为', self.packet['governance']['forecast_influence_notice'])

    def test_forbidden_uses_include_employment(self):
        text = ' '.join(self.packet['governance']['forbidden_uses'])
        self.assertIn('雇佣', text)


if __name__ == '__main__':
    unittest.main(verbosity=2)
