#!/usr/bin/env python3
import json
import unittest
from pathlib import Path
from jsonschema import Draft202012Validator, RefResolver

ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = ROOT / 'schemas'


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


class SchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.schemas = {p.name: load(p) for p in SCHEMAS.glob('*.json')}
        cls.store = {s.get('$id'): s for s in cls.schemas.values() if s.get('$id')}
        # Also support relative file names used by the schemas.
        cls.store.update({name: schema for name, schema in cls.schemas.items()})

    def validator(self, name):
        schema = self.schemas[name]
        resolver = RefResolver(base_uri=SCHEMAS.as_uri() + '/', referrer=schema, store=self.store)
        return Draft202012Validator(schema, resolver=resolver)

    def test_signals(self):
        payload = load(ROOT / 'samples' / 'sample_signals.json')
        v = self.validator('civilization_signal.schema.json')
        for signal in payload['signals']:
            v.validate(signal)

    def test_purpose_contract(self):
        profile = load(ROOT / 'samples' / 'sample_profile.json')
        self.validator('purpose_contract.schema.json').validate(profile['purpose_contract'])

    def test_profile(self):
        profile = load(ROOT / 'samples' / 'sample_profile.json')
        self.validator('individual_profile.schema.json').validate(profile)

    def test_actualization(self):
        obj = load(ROOT / 'samples' / 'sample_actualization.json')
        self.validator('actualization_event.schema.json').validate(obj)

    def test_runtime_packet(self):
        result = load(ROOT / 'outputs' / 'demo_result.json')
        self.validator('update_packet.schema.json').validate(result['update_packet'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
