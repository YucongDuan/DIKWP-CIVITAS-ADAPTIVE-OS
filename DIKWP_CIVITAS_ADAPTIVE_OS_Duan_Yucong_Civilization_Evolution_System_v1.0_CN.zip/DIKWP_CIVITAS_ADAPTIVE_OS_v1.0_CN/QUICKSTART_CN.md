# DIKWP-CIVITAS ADAPTIVE OS v1.0 快速启动

## 1. 系统定位

本系统把多源文明信号转换为：

1. 十二维文明状态；
2. 六类情景的相对概率；
3. 个体在当前情景组合中的准备度差距与结构资产；
4. 7 / 30 / 90 / 365 日主动更新行动；
5. DIKWP-R 更新包；
6. U2 外部实际化校准结果。

它是研究与决策支持原型，不是命运预测器，也不得用于雇佣淘汰、保险、信贷、福利、政治操纵或未经同意的第三方人格评分。

## 2. 直接打开离线驾驶舱

打开：

```text
prototype/index.html
```

无需联网、模型 API 或数据库。页面内可以：

- 查看六类文明情景概率；
- 查看十二维文明状态；
- 调整个体准备度滑块；
- 重新生成差距与选项空间；
- 查看 U7 / U30 / U90 / U365 行动；
- 下载当前 UpdatePacket JSON。

## 3. 运行 Python 参考内核

需要 Python 3.10 或更高版本。运行：

```bash
python runtime/civitas_runtime.py --demo
```

默认输出：

```text
outputs/demo_result.json
```

自定义输入：

```bash
python runtime/civitas_runtime.py \
  --config configs/default_dimensions.json \
  --scenarios configs/scenario_library.json \
  --profile samples/sample_profile.json \
  --signals samples/sample_signals.json \
  --actualization samples/sample_actualization.json \
  --output outputs/custom_result.json
```

## 4. 运行测试

在系统根目录运行：

```bash
python -m unittest discover -s tests -v
```

v1.0 包含：

- 10 项运行时行为测试；
- 5 项 JSON Schema 测试；
- 合计 15 项。

## 5. 修改文明维度与情景

- 文明维度、个体维度、时间尺度和默认参数：`configs/default_dimensions.json`
- 六类情景、原型状态、个体要求、触发器、机会和风险：`configs/scenario_library.json`

任何修改都应：

1. 更新版本号；
2. 保存变更原因；
3. 重跑测试；
4. 生成新的输出哈希；
5. 在真实事件发生后写入 ActualizationEvent。

## 6. 关键数据对象

`schemas/` 中包含：

- `civilization_signal.schema.json`
- `individual_profile.schema.json`
- `forecast_branch.schema.json`
- `update_packet.schema.json`
- `actualization_event.schema.json`
- `purpose_contract.schema.json`

## 7. 默认示例边界

`samples/` 中的文明信号、个体画像和实际化事件均为合成演示，不代表现实世界统计，也不构成对任何真实个人的心理、职业、健康或经济判断。

## 8. 推荐运行节奏

- 每周：信号删除、能量门控与 U7 更新；
- 每月：能力、关系、资源和 U30 更新；
- 每季度：三情景演练、公共产品和 U90 更新；
- 每年：目的合同、身份组合、资源账户、错误报告和 U365 更新。

## 9. 最小治理要求

- 本人知情同意；
- 本地优先与最小必要数据；
- 不把分数解释为人的价值；
- 高影响行动必须人工复核；
- 所有行动具有成功指标和 Kill 条件；
- 预测公开后记录 Forecast Influence Ledger；
- 外部事实进入只追加 U2 Actualization Ledger。
