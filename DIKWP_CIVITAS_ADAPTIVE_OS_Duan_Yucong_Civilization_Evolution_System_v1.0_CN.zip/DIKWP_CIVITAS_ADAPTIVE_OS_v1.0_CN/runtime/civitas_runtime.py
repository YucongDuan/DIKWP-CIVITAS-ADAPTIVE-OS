#!/usr/bin/env python3
"""DIKWP-CIVITAS ADAPTIVE OS reference runtime.

A local-first, deterministic demonstration of:
1) civilization signal aggregation;
2) scenario-lattice forecasting;
3) individual civilization-position assessment;
4) DIKWP-R active update packet generation;
5) U2 actualization calibration.

This runtime is a research/decision-support prototype. It does not rank human worth,
predict a person's fate, or authorize high-impact decisions.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "default_dimensions.json"
DEFAULT_SCENARIOS = ROOT / "configs" / "scenario_library.json"
DEFAULT_PROFILE = ROOT / "samples" / "sample_profile.json"
DEFAULT_SIGNALS = ROOT / "samples" / "sample_signals.json"
DEFAULT_ACTUALIZATION = ROOT / "samples" / "sample_actualization.json"
DEFAULT_OUTPUT = ROOT / "outputs" / "demo_result.json"

CIV_DIMS = [
    "energy_metabolism", "ecological_regeneration", "information_integrity",
    "knowledge_reliability", "ai_agency", "governance_adaptability",
    "distribution_mobility", "trust_cohesion", "security_resilience",
    "human_capability", "meaning_legitimacy", "future_optionality",
]
IND_DIMS = [
    "vital_energy", "sensemaking", "learning_velocity", "skill_optionality",
    "ai_leverage", "economic_runway", "network_trust", "institutional_literacy",
    "adaptation", "purpose_integrity", "resilience", "contribution",
]

DIMENSION_CN = {
    "vital_energy": "生命能量与时间主权",
    "sensemaking": "信息辨析与意义构建",
    "learning_velocity": "学习速度与知识更新",
    "skill_optionality": "技能组合与未来选项",
    "ai_leverage": "AI 与工具杠杆",
    "economic_runway": "经济跑道与资源缓冲",
    "network_trust": "关系网络与可信协作",
    "institutional_literacy": "制度理解与组织导航",
    "adaptation": "适应、反事实与主动更新",
    "purpose_integrity": "目的完整性与伦理边界",
    "resilience": "韧性、修复与身份可塑性",
    "contribution": "文明贡献与公共产品能力",
}

HORIZON_WEIGHT = {"H1": 1.00, "H2": 0.86, "H3": 0.68, "H4": 0.52}

ACTION_LIBRARY: Dict[str, Dict[str, Tuple[str, str, str, str]]] = {
    "vital_energy": {
        "U7": ("建立七日能量止损协议", "冻结两个非关键承诺，安排连续三天可验证的睡眠与深度工作窗口。", "七日平均主观能量提高至少8分，深度工作完成率达到70%。", "若出现持续失眠、明显躯体症状或评分继续下降，停止新增项目并寻求专业支持。"),
        "U30": ("建立个人能量账本", "记录睡眠、会议、沟通、创造与恢复的能量流，识别三类最大泄漏点。", "形成不少于21天数据并减少至少20%的低价值占用。", "若记录本身增加明显负担，缩减为每天一次三项记录。"),
        "U90": ("重构研究与交付节奏", "把项目分成旗舰航道、维护航道和地平线银行，设置固定恢复周。", "核心交付准时率提高，连续四周无极端透支。", "若旗舰航道超过两条或维护债务继续增长，触发项目下线。"),
        "U365": ("建立可持续认知寿命计划", "把身体健康、注意力和长期创造力写入年度资源配置与目的合同。", "年度健康、工作和恢复指标同时达标，不以单一产出掩盖长期损耗。", "任何不可逆健康风险优先于发布和声誉目标。"),
    },
    "sensemaking": {
        "U7": ("启动每周文明信号审查", "只保留十条高影响信号，并为每条写出来源、反证和下一步验证。", "完成一张可复查的 Signal Ledger，至少三条信号被降权或否定。", "若无法说明来源或反证，该信号不得进入行动层。"),
        "U30": ("建立个人事实系统", "为政策、技术、生态、社会和个人信号设置来源分级与冲突处理。", "80%的关键判断可追溯到原始证据或明确标为假设。", "若系统变成收藏库而没有预测与行动，删除一半字段。"),
        "U90": ("发布一次可复现情景研判", "选择一个文明变量，公开假设、指标、情景、失败条件和复盘日期。", "至少一名外部同行完成复核或反驳，产生可记录更新。", "若结论不可被外部证据推翻，不得称为预测。"),
        "U365": ("形成文明观察方法论", "把信号选择、模型更新、错误分类和公开修订形成版本化公共协议。", "年度预测校准报告可引用、可复现，并公开重大错误。", "不得以影响力或身份保护错误结论。"),
    },
    "learning_velocity": {
        "U7": ("完成一个最小复现任务", "选择与主航道直接相关的论文、协议或工具，在七天内跑通最小例。", "产生代码、日志和一页复现说明。", "若三天仍无法确定最小任务，立即缩小范围。"),
        "U30": ("建立能力淘汰与迁移清单", "标记未来24个月可能贬值、保持和升值的能力，并配置学习实验。", "至少完成一个新能力的可公开作品。", "不因追逐热词放弃核心理论与方法护城河。"),
        "U90": ("形成跨域双循环学习", "把技术能力与制度/科学传播能力组成同一项目交付。", "一项成果同时被技术同行和非技术场景方理解与使用。", "若跨域只增加包装而无实际采用，回到单一问题。"),
        "U365": ("构建个人学习操作系统", "按问题、复现、教学、公共产品和淘汰五类管理知识。", "年度至少三项能力进入可独立交付层。", "禁止只用阅读时长代替能力形成。"),
    },
    "skill_optionality": {
        "U7": ("绘制技能单点故障图", "识别当前职业和研究组合对单一平台、资助、模型或身份的依赖。", "列出三条可迁移替代路径。", "不得把尚未验证的副技能当作安全缓冲。"),
        "U30": ("建立第二可交付能力", "选择一个能与主航道互补且可在30天形成作品的技能。", "完成一项可独立展示、可被他人调用的成果。", "若新技能与目的合同无关或只增加焦虑，停止。"),
        "U90": ("构建T型能力组合", "保留一项深专长，并建立两项跨域连接能力和一个场景接口。", "在两个不同场景中复用同一核心方法。", "若跨域导致核心深度显著下降，减少并行方向。"),
        "U365": ("年度选项空间审计", "评估技能、地区、组织、收入和技术栈的可迁移性。", "任何单一依赖失效时仍有不少于两条可行路径。", "不以短期薪酬最大化换取不可逆锁定。"),
    },
    "ai_leverage": {
        "U7": ("审计一个AI工作流", "选择高频流程，记录输入、模型、工具、人工复核、失败和回滚。", "节省时间同时保持证据链完整。", "若错误无法回滚或数据边界不清，撤回自动化。"),
        "U30": ("形成可复用智能体模板", "把一个工作流打包为本地优先、可替换模型、可审计的模板。", "至少两次重复使用且结果一致。", "不得把专有平台当作唯一记忆和身份载体。"),
        "U90": ("建立人机责任分层", "把判断、生成、验证、授权和现实行动分配给不同角色。", "高影响动作全部有明确人类批准与日志。", "出现自我批准或不可解释工具链时立即阻断。"),
        "U365": ("建设个人认知基础设施", "让AI增强研究、协作和公共产品维护，而非只提高输出数量。", "年度维护债务下降，复现率和外部采用上升。", "若产量上升但健康、质量和信任下降，降低自动化强度。"),
    },
    "economic_runway": {
        "U7": ("完成资源暴露盘点", "列出未来90天现金流、固定成本、项目依赖和可削减项。", "明确最低生存线和三种缩减方案。", "不得在信息不完整时新增高杠杆承诺。"),
        "U30": ("建立八个月以上转型缓冲", "调整成本、收入和项目结构，优先提高可选择时间。", "跑道增加或固定成本下降10%以上。", "不通过牺牲核心健康和合规换取表面跑道。"),
        "U90": ("构建三层资源组合", "区分稳定现金流、增长项目和高不确定探索预算。", "任何单一来源占比下降，探索预算受限且可停止。", "高不确定项目不得挪用基本生活与维护资金。"),
        "U365": ("建立文明转型资本账户", "为学习、迁移、公共产品和应急分别配置资源。", "年度每类账户均有明确使用与复盘记录。", "不得把全部资源绑定单一情景预测。"),
    },
    "network_trust": {
        "U7": ("修复三个关键弱连接", "向三位跨域联系人发送有具体价值的更新或帮助，而非泛化社交。", "至少形成一次后续协作或高质量反馈。", "不得在没有边界和互惠条件下承诺长期工作。"),
        "U30": ("建立可信协作小组", "围绕一个可交付问题形成3-5人小组，明确RACI、版本和退出条件。", "30天内产生一个共同成果。", "若责任长期模糊或贡献失衡，重签协作契约。"),
        "U90": ("形成跨组织互证网络", "邀请学术、产业、治理和用户代表共同评审一项系统。", "至少三类角色留下可追踪意见与修订。", "不得用挂名专家替代实际审查。"),
        "U365": ("建设长期信任资产", "通过持续维护公共产品和兑现承诺积累可信关系。", "核心网络中有多方向互惠，不依赖单一中心人物。", "发现声誉与事实冲突时优先公开修正。"),
    },
    "institutional_literacy": {
        "U7": ("绘制制度接口图", "为当前主项目列出主管部门、标准、采购、伦理、数据和责任链。", "识别至少两个原先忽略的准入条件。", "高风险项目在无责任主体时不得进入试点。"),
        "U30": ("完成一次标准映射", "把DIKWP术语映射到现有治理、审计或采购语言。", "形成双语术语表和一页场景符合性说明。", "若新术语无法与既有制度对接，暂停扩展概念。"),
        "U90": ("运行一个合规沙盒", "在有限场景中测试权限、日志、申诉、数据最小化和事故响应。", "产生第三方可审查的试点报告。", "出现数据授权不清或责任转移时立即停止。"),
        "U365": ("建立制度化公共产品路径", "把研究、标准、采购、场景和维护组织连接成长期机制。", "至少一项成果被外部组织采用或引用。", "不得让商业利益控制评测结论。"),
    },
    "adaptation": {
        "U7": ("写出三条可证伪预测", "为最重要判断写出时间、阈值、反证和应对。", "七天后至少复盘一次概率变化。", "没有反证条件的判断不得驱动高成本动作。"),
        "U30": ("建立Kill/Recovery矩阵", "为主项目设置继续、缩减、暂停、转向和恢复条件。", "任何方向都有明确退出而非靠情绪坚持。", "触发Kill条件后不得通过改写叙事逃避。"),
        "U90": ("运行三情景反事实演练", "对协同丰裕、碎片化加速和冲击重置分别演练个人路径。", "形成共同行动、情景专属行动和对冲行动。", "若演练只产生同一建议，重新检查模型差异。"),
        "U365": ("发布年度错误与更新报告", "记录预测失败、身份变化、资源误配和方法修订。", "重大错误均有原因分类和下一版本改动。", "不得删除不利于个人叙事的历史记录。"),
    },
    "purpose_integrity": {
        "U7": ("重读并压缩目的合同", "把长期目的、授权、不可交易原则和停止条件压缩到一页。", "所有新增行动都能映射到合同条款。", "无法映射或冲突的行动先暂停。"),
        "U30": ("执行目的—项目对账", "审查每个项目服务谁、产生什么公共价值、消耗什么长期能力。", "下线至少一个低闭环项目。", "不得以沉没成本和声誉维护为唯一继续理由。"),
        "U90": ("建立外部伦理审查", "邀请不受项目利益影响的人审查风险、受影响群体和退出机制。", "形成公开或受控的审查记录。", "重大异议未处理前不扩大部署。"),
        "U365": ("年度目的版本治理", "允许身份与目的更新，但保存变更原因、证据和受影响承诺。", "目的版本可追溯，旧承诺被妥善结束或转移。", "不得把目的更新变成逃避责任。"),
    },
    "resilience": {
        "U7": ("建立失败后的72小时恢复卡", "定义身体、信息、关系、财务和项目的最小恢复动作。", "出现冲击时可按卡片执行，而非临时失控。", "涉及医疗或安全风险时优先专业支持。"),
        "U30": ("增加关键功能冗余", "为数据、协作、收入、工具和知识各增加一个替代路径。", "至少两个单点故障被消除。", "冗余不得显著增加不可维护复杂度。"),
        "U90": ("进行一次文明冲击桌面演练", "模拟平台中断、资助中止、舆论争议或健康事件。", "在48小时内完成角色与资源切换方案。", "演练发现无可恢复风险时，立即降低暴露。"),
        "U365": ("建立身份可塑性档案", "记录自己除当前头衔外可承担的角色、技能和贡献。", "至少三种角色具有真实作品或关系支持。", "不得把组织职位等同于完整自我。"),
    },
    "contribution": {
        "U7": ("选择一个最小公共产品", "把一个内部成果整理为他人可引用、可复现、可执行的单元。", "发布版本号、使用说明和限制。", "若无法说明受益者和维护者，先不发布。"),
        "U30": ("建立公共产品维护闭环", "设置问题反馈、版本记录、复现样例和责任人。", "至少一名外部用户完成独立使用。", "下载量不得替代实际复现和采用。"),
        "U90": ("交付跨场景文明工具", "把一个DIKWP方法用于研究、教育、治理或产业中的两个场景。", "形成两份可比较案例和失败记录。", "场景差异被掩盖或风险不可控时停止迁移。"),
        "U365": ("形成年度文明贡献组合", "平衡发现、修复、照护、协调和标准建设，不只追求新概念。", "组合中至少三类贡献留下可验证证据。", "不得以个人品牌吞并共同贡献。"),
    },
}


@dataclass(frozen=True)
class RuntimeInputs:
    config: Mapping[str, Any]
    scenarios: Sequence[Mapping[str, Any]]
    profile: Mapping[str, Any]
    signals: Sequence[Mapping[str, Any]]
    as_of: str


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))


def stable_hash(obj: Any) -> str:
    payload = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def signal_weight(signal: Mapping[str, Any], half_life_days: float) -> float:
    recency = max(float(signal.get("recency_days", 0)), 0.0)
    decay = math.exp(-math.log(2.0) * recency / max(half_life_days, 1.0))
    return (
        float(signal.get("confidence", 0.0))
        * float(signal.get("source_quality", 0.0))
        * HORIZON_WEIGHT.get(str(signal.get("horizon", "H2")), 0.7)
        * decay
    )


def aggregate_civilization_state(config: Mapping[str, Any], signals: Sequence[Mapping[str, Any]]) -> Tuple[Dict[str, float], Dict[str, Any]]:
    base = float(config.get("base_state", 50))
    half_life = float(config.get("decay_half_life_days", 180))
    raw_delta = {dim: 0.0 for dim in CIV_DIMS}
    evidence_count = {dim: 0 for dim in CIV_DIMS}
    effective_weight = {dim: 0.0 for dim in CIV_DIMS}
    for signal in signals:
        dim = str(signal["dimension"])
        if dim not in raw_delta:
            continue
        w = signal_weight(signal, half_life)
        raw_delta[dim] += float(signal["direction"]) * float(signal["magnitude"]) * w
        effective_weight[dim] += w
        evidence_count[dim] += 1
    state: Dict[str, float] = {}
    # 42 points is the maximum conceptual shift from neutral under current demo calibration.
    for dim in CIV_DIMS:
        delta = 42.0 * math.tanh(raw_delta[dim])
        state[dim] = round(clamp(base + delta), 2)
    diagnostics = {
        "raw_delta": {k: round(v, 5) for k, v in raw_delta.items()},
        "effective_weight": {k: round(v, 5) for k, v in effective_weight.items()},
        "evidence_count": evidence_count,
        "coverage": round(sum(1 for v in evidence_count.values() if v > 0) / len(CIV_DIMS), 4),
    }
    return state, diagnostics


def scenario_distance(state: Mapping[str, float], prototype: Mapping[str, float], dimension_weights: Mapping[str, float]) -> float:
    num = 0.0
    den = 0.0
    for dim in CIV_DIMS:
        w = float(dimension_weights.get(dim, 1.0))
        diff = (float(state[dim]) - float(prototype[dim])) / 100.0
        num += w * diff * diff
        den += w
    return math.sqrt(num / max(den, 1e-9))


def softmax(values: Sequence[float]) -> List[float]:
    if not values:
        return []
    max_v = max(values)
    exps = [math.exp(v - max_v) for v in values]
    total = sum(exps)
    return [e / total for e in exps]


def forecast_scenarios(config: Mapping[str, Any], scenarios: Sequence[Mapping[str, Any]], state: Mapping[str, float]) -> List[Dict[str, Any]]:
    dimension_weights = {d["id"]: float(d.get("weight", 1.0)) for d in config["civilization_dimensions"]}
    temperature = float(config.get("forecast_temperature", 0.18))
    distances = [scenario_distance(state, s["prototype"], dimension_weights) for s in scenarios]
    logits = [-d / max(temperature, 0.01) for d in distances]
    probs = softmax(logits)
    branches = []
    for scenario, distance, probability in zip(scenarios, distances, probs):
        branches.append({
            "scenario_id": scenario["id"],
            "scenario_name": scenario["name"],
            "probability": round(probability, 6),
            "distance": round(distance, 6),
            "triggers": list(scenario["triggers"]),
            "opportunities": list(scenario["opportunities"]),
            "risks": list(scenario["risks"]),
            "strategic_posture": scenario["strategic_posture"],
            "horizon": "H2",
        })
    branches.sort(key=lambda x: x["probability"], reverse=True)
    # Preserve exact probability sum after rounding.
    correction = round(1.0 - sum(b["probability"] for b in branches), 6)
    branches[0]["probability"] = round(branches[0]["probability"] + correction, 6)
    return branches


def weighted_individual_requirements(scenarios: Sequence[Mapping[str, Any]], forecast: Sequence[Mapping[str, Any]]) -> Dict[str, float]:
    scenario_map = {s["id"]: s for s in scenarios}
    req = {d: 0.0 for d in IND_DIMS}
    for branch in forecast:
        scenario = scenario_map[branch["scenario_id"]]
        p = float(branch["probability"])
        for dim in IND_DIMS:
            req[dim] += p * float(scenario["individual_requirements"][dim])
    return {k: round(v, 2) for k, v in req.items()}


def normalized_entropy(probabilities: Iterable[float]) -> float:
    ps = [p for p in probabilities if p > 0]
    if len(ps) <= 1:
        return 0.0
    h = -sum(p * math.log(p) for p in ps)
    return h / math.log(len(ps))


def assess_individual(profile: Mapping[str, Any], requirements: Mapping[str, float]) -> Dict[str, Any]:
    scores = profile["scores"]
    gaps = {dim: round(float(requirements[dim]) - float(scores[dim]), 2) for dim in IND_DIMS}
    priorities = sorted(IND_DIMS, key=lambda d: gaps[d], reverse=True)
    priority_dims = [d for d in priorities if gaps[d] > 4][:6]
    if len(priority_dims) < 4:
        priority_dims = priorities[:4]
    strengths = [d for d in sorted(IND_DIMS, key=lambda d: float(scores[d]) - float(requirements[d]), reverse=True)
                 if float(scores[d]) - float(requirements[d]) >= 5.5][:5]
    fragilities = [d for d in priorities if gaps[d] >= 12]
    return {
        "weighted_requirements": dict(requirements),
        "gaps": gaps,
        "strengths": [DIMENSION_CN[d] for d in strengths],
        "priority_dimensions": priority_dims,
        "priority_dimension_names": [DIMENSION_CN[d] for d in priority_dims],
        "fragilities": [DIMENSION_CN[d] for d in fragilities],
        "assessment_note": "分数表示在当前情景组合中的准备度差距，不表示人的价值、人格、道德等级或必然命运。",
    }


def make_action(cycle: str, dim: str, index: int, top_scenario: str) -> Dict[str, str]:
    title, detail, metric, kill = ACTION_LIBRARY[dim][cycle]
    return {
        "action_id": f"{cycle}-{index:02d}-{dim}",
        "title": title,
        "dimension": dim,
        "rationale": f"{detail} 当前首要情景为“{top_scenario}”，该动作优先修复 {DIMENSION_CN[dim]} 的情景缺口。",
        "success_metric": metric,
        "kill_condition": kill,
        "effort": {"U7":"low_to_medium","U30":"medium","U90":"medium_to_high","U365":"strategic"}[cycle],
        "evidence_link": f"assessment.gaps.{dim}",
    }


def generate_actions(assessment: Mapping[str, Any], forecast: Sequence[Mapping[str, Any]], profile: Mapping[str, Any]) -> Dict[str, List[Dict[str, str]]]:
    priorities = list(assessment["priority_dimensions"])
    top_name = forecast[0]["scenario_name"]
    # Always protect vital energy if below 55 even if another dimension has a larger numerical gap.
    if float(profile["scores"]["vital_energy"]) < 55 and "vital_energy" not in priorities:
        priorities.insert(0, "vital_energy")
    # Avoid duplicate dimensions while preserving order.
    priorities = list(dict.fromkeys(priorities))
    while len(priorities) < 6:
        for d in IND_DIMS:
            if d not in priorities:
                priorities.append(d)
            if len(priorities) >= 6:
                break
    return {
        "U7": [make_action("U7", d, i + 1, top_name) for i, d in enumerate(priorities[:2])],
        "U30": [make_action("U30", d, i + 1, top_name) for i, d in enumerate(priorities[:3])],
        "U90": [make_action("U90", d, i + 1, top_name) for i, d in enumerate(priorities[:4])],
        "U365": [make_action("U365", d, i + 1, top_name) for i, d in enumerate(priorities[:4])],
    }


def build_dikwp_r(signals: Sequence[Mapping[str, Any]], state: Mapping[str, float], forecast: Sequence[Mapping[str, Any]], assessment: Mapping[str, Any], actions: Mapping[str, Any]) -> Dict[str, List[str]]:
    strongest = sorted(signals, key=lambda s: abs(float(s["direction"]) * float(s["magnitude"]) * float(s["confidence"])), reverse=True)[:5]
    weakest_state = sorted(state, key=lambda d: state[d])[:4]
    strongest_state = sorted(state, key=lambda d: state[d], reverse=True)[:3]
    top = forecast[0]
    second = forecast[1]
    return {
        "D": [f"{s['signal_id']}：{s['description']}（置信度{float(s['confidence']):.2f}）" for s in strongest],
        "I": [
            f"当前文明状态最薄弱的维度为：{', '.join(weakest_state)}。",
            f"相对较强的维度为：{', '.join(strongest_state)}。",
            f"信号共同指向技术速度与制度/信任速度不一致的结构性张力。",
        ],
        "K": [
            f"首要情景为“{top['scenario_name']}”，概率 {top['probability']:.1%}；第二情景为“{second['scenario_name']}”，概率 {second['probability']:.1%}。",
            "预测不是单一路径；情景概率表示当前证据下的相对匹配，必须随外部实际化更新。",
            "文明演化具有反身性：公开预测会改变个体与组织行为，因此需要记录预测影响。",
        ],
        "W": [
            f"优先修复个体缺口：{', '.join(assessment['priority_dimension_names'][:4])}。",
            "采用稳健共同行动、情景专属行动和小额高不确定期权三层组合。",
            "不以短期效率最大化牺牲长期认知寿命、伦理边界和未来选项。",
        ],
        "P": [
            "七日先稳定能量和事实系统，三十日形成一个可验证能力，九十日完成一个跨场景公共产品，年度重写目的与资源配置。",
            f"当前七日动作：{'；'.join(a['title'] for a in actions['U7'])}。",
            "所有高影响行动必须映射到 Purpose Contract，并保留人工暂停、外部审查和回滚。",
        ],
        "R": [
            "场景库是结构化假设，不是未来的穷尽列表；黑天鹅和规则变化可能使全部情景失配。",
            "个人数据不得用于雇佣、保险、信贷、政治操纵或未经同意的第三方评分。",
            "系统需要在每次实际事件后更新预测误差、行动副作用和模型影响账本。",
        ],
    }


def compute_optionality(profile: Mapping[str, Any], state: Mapping[str, float], assessment: Mapping[str, Any], actions: Mapping[str, Any]) -> Dict[str, Any]:
    s = profile["scores"]
    personal = 0.24 * s["skill_optionality"] + 0.18 * s["economic_runway"] + 0.18 * s["network_trust"] + 0.20 * s["adaptation"] + 0.20 * s["resilience"]
    current = 0.72 * personal + 0.28 * state["future_optionality"]
    gap_pressure = sum(max(0.0, float(g)) for g in assessment["gaps"].values()) / (len(IND_DIMS) * 100.0)
    action_breadth = len({a["dimension"] for cycle in actions.values() for a in cycle}) / len(IND_DIMS)
    projected = clamp(current + 9.0 * action_breadth - 7.0 * gap_pressure)
    lock_in = []
    if s["economic_runway"] < 55:
        lock_in.append("经济缓冲偏低，可能迫使个体接受与长期目的冲突的短期选择。")
    if s["skill_optionality"] < 65:
        lock_in.append("技能组合偏窄，存在单一技术或组织路径锁定。")
    if s["network_trust"] < 60:
        lock_in.append("可信协作网络不足，情景切换时资源和信息来源可能断裂。")
    if state["future_optionality"] < 45:
        lock_in.append("宏观未来选项收缩，需要增加本地替代、开放格式和可迁移资产。")
    return {
        "current": round(current, 2),
        "projected": round(projected, 2),
        "delta": round(projected - current, 2),
        "lock_in_risks": lock_in or ["当前未发现高强度单点锁定，但仍需季度复核。"],
    }


def build_packet(inputs: RuntimeInputs) -> Dict[str, Any]:
    state, diagnostics = aggregate_civilization_state(inputs.config, inputs.signals)
    forecast = forecast_scenarios(inputs.config, inputs.scenarios, state)
    requirements = weighted_individual_requirements(inputs.scenarios, forecast)
    assessment = assess_individual(inputs.profile, requirements)
    actions = generate_actions(assessment, forecast, inputs.profile)
    dikwp_r = build_dikwp_r(inputs.signals, state, forecast, assessment, actions)
    optionality = compute_optionality(inputs.profile, state, assessment, actions)
    entropy = normalized_entropy([float(b["probability"]) for b in forecast])
    coverage = float(diagnostics["coverage"])
    residual_uncertainty = clamp(100.0 * (0.62 * entropy + 0.38 * (1.0 - coverage)), 0.0, 100.0) / 100.0
    packet_core = {
        "generated_at": f"{inputs.as_of}T00:00:00Z",
        "profile_id": inputs.profile["profile_id"],
        "civilization_state": state,
        "scenario_forecast": forecast,
        "individual_assessment": assessment,
        "dikwp_r": dikwp_r,
        "actions": actions,
        "optionality": optionality,
        "governance": {
            "human_review_required": True,
            "forbidden_uses": [
                "雇佣淘汰或晋升的自动化决定", "保险、信贷或公共福利的惩罚性评分",
                "政治操纵、心理定向和未经同意的画像", "把准备度分数解释为人的价值或命运",
            ],
            "purpose_contract_id": inputs.profile["purpose_contract"]["contract_id"],
            "forecast_influence_notice": "本预测可能改变使用者行为。任何部署必须记录谁看到了预测、采取了什么行动，以及这些行动是否反过来改变了被预测系统。",
            "residual_uncertainty": round(residual_uncertainty, 4),
        },
    }
    packet_id = "CIVUP-" + stable_hash(packet_core)[:16].upper()
    packet = {"packet_id": packet_id, **packet_core}
    packet["diagnostics"] = diagnostics
    packet["reproducibility_hash"] = stable_hash(packet)
    return packet


def calibrate_forecast(packet: Mapping[str, Any], actualization: Mapping[str, Any]) -> Dict[str, Any]:
    observed = str(actualization["observed_scenario"])
    probabilities = {b["scenario_id"]: float(b["probability"]) for b in packet["scenario_forecast"]}
    brier = sum((p - (1.0 if sid == observed else 0.0)) ** 2 for sid, p in probabilities.items()) / len(probabilities)
    obs_state = actualization.get("observed_dimension_values", {})
    common = [d for d in CIV_DIMS if d in obs_state]
    rmse = math.sqrt(sum((float(packet["civilization_state"][d]) - float(obs_state[d])) ** 2 for d in common) / max(len(common), 1))
    rank = next((i + 1 for i, b in enumerate(packet["scenario_forecast"]) if b["scenario_id"] == observed), None)
    return {
        "actualization_id": actualization["actualization_id"],
        "observed_scenario": observed,
        "observed_rank_in_forecast": rank,
        "observed_probability": round(probabilities.get(observed, 0.0), 6),
        "multiclass_brier_score": round(brier, 6),
        "civilization_state_rmse": round(rmse, 4),
        "calibration_interpretation": "分数越低越好；单次校准不能证明模型有效，至少需要多个独立时期和未参与建模的数据。",
        "u2_actualization_principle": "事件发生前保留概率，事件发生后把外部事实写入只追加账本，并允许其否定个人与系统叙事。",
    }


def load_inputs(config_path: Path, scenarios_path: Path, profile_path: Path, signals_path: Path) -> RuntimeInputs:
    config = load_json(config_path)
    scenario_payload = load_json(scenarios_path)
    profile = load_json(profile_path)
    signal_payload = load_json(signals_path)
    return RuntimeInputs(
        config=config,
        scenarios=scenario_payload["scenarios"],
        profile=profile,
        signals=signal_payload["signals"],
        as_of=signal_payload.get("as_of", profile.get("assessment_date", "2026-07-14")),
    )


def run_demo(output: Path = DEFAULT_OUTPUT, actualization_path: Path | None = DEFAULT_ACTUALIZATION) -> Dict[str, Any]:
    inputs = load_inputs(DEFAULT_CONFIG, DEFAULT_SCENARIOS, DEFAULT_PROFILE, DEFAULT_SIGNALS)
    packet = build_packet(inputs)
    result: Dict[str, Any] = {
        "system": "DIKWP-CIVITAS ADAPTIVE OS",
        "version": "1.0.0",
        "mode": "dikwp_mesh",
        "update_packet": packet,
    }
    if actualization_path and actualization_path.exists():
        result["calibration"] = calibrate_forecast(packet, load_json(actualization_path))
    result["result_hash"] = stable_hash(result)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="DIKWP-CIVITAS civilization forecast and active-update runtime")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--scenarios", type=Path, default=DEFAULT_SCENARIOS)
    parser.add_argument("--profile", type=Path, default=DEFAULT_PROFILE)
    parser.add_argument("--signals", type=Path, default=DEFAULT_SIGNALS)
    parser.add_argument("--actualization", type=Path, default=DEFAULT_ACTUALIZATION)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--demo", action="store_true", help="run bundled deterministic demo")
    args = parser.parse_args()

    if args.demo:
        result = run_demo(args.output, args.actualization)
    else:
        inputs = load_inputs(args.config, args.scenarios, args.profile, args.signals)
        packet = build_packet(inputs)
        result = {"system":"DIKWP-CIVITAS ADAPTIVE OS","version":"1.0.0","mode":"dikwp_mesh","update_packet":packet}
        if args.actualization and args.actualization.exists():
            result["calibration"] = calibrate_forecast(packet, load_json(args.actualization))
        result["result_hash"] = stable_hash(result)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    top = result["update_packet"]["scenario_forecast"][0]
    print(f"Top scenario: {top['scenario_name']} ({top['probability']:.2%})")
    print(f"Packet: {result['update_packet']['packet_id']}")
    print(f"Result hash: {result['result_hash']}")
    print(f"Output: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
